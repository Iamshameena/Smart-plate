"""smart_plate URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from app1 import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.login_page),
    path('logout/',views.login_page),
    path('adminhome/',views.admin_home),
    path('add_account/',views.account_add),
    path('save_account/',views.save_account),
    path('remove_account/',views.remove_account_view),
    path('remove/<int:id>',views.remove),
    path('suspend_account/',views.suspend_account),
    path('suspend/<int:id>',views.suspend),
    path('add_menu/',views.add_menu),
    path('save_menu/',views.save_menu),
    path('remove_menu_view/',views.remove_menu_view),
    path('remove_menu/<int:id>',views.remove_menu),
    path('update_price_view/',views.update_price_view),
    path('update_price/<int:id>',views.update_price),
    path('update/<int:id>',views.update),
    path('add_table/',views.table_add),
    path('save_table/',views.save_table),
    path('remove_table_view/',views.remove_table_view),
    path('remove_table/<int:id>',views.remove_table),
    path('login/',views.login_page),
    path('save_login/',views.save_login),
    path('form/',views.form),
    path('kitchenhome/',views.kitchen_home),
    path('counterhome/',views.counter_home),
    path('tablehome/',views.table_home),
    path('view_menu/',views.view_menu),
    path('order/<int:id>',views.order_menu),
    path('save_order/<int:id>',views.save_order),

    path('finish/',views.finish),
    path('give_complaint/',views.give_complaint),
    path('give_review/',views.give_review),
    path('save_complaint/',views.save_complaint),
    path('save_review/',views.save_review),
    path('public_view_menu/',views.public_view_menu),
    path('view_review/<str:id>',views.view_review),
    path('order_view/',views.order_view),
    path('view_more/<str:id>',views.view_more),
    path('accept_order/<int:id>,<str:oid>',views.accept_order),
    path('reject_order/<int:id>,<str:oid>',views.reject_order),
    path('finish_order/<str:id>',views.finish_order),
    path('counter_view_order/',views.counter_view_order),
    path('bill_gen/<str:id>',views.bill_gen),
    path('bill_generate/<int:id>,<str:ordrid>',views.bill_generate),
    path('finish_bill/<str:id>',views.finish_bill),
    path('view_bill/',views.view_bill),
    path('view_bill_details/<str:bid>',views.view_bill_details),
    path('bill_payment/<str:b_no>,<str:amt>',views.bill_payment),
    path('save_payment/',views.save_payment),
    path('counter_view_bill/',views.counter_view_bill),
    path('counter_view_payment/<str:bid>',views.counter_view_payment),
    path('view_complaints/',views.view_complaints),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)