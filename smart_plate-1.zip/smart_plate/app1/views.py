from django.shortcuts import render,redirect
from app1.models import account,login,menu,table,order,order_details,complaint,review,bill,bill_details,payment
from django.http import HttpResponse
from django.conf import settings
from django.core.files.storage import FileSystemStorage
import datetime
# from datetime import date 
import datetime
from django.db.models import Sum
# from django.db.models.sql.aggregates.Sum

# Create your views here.
def form(request):
    return render(request,"form.html")

def home(request):
    return render(request,"home.html")

def admin_home(request):
    return render(request,"admin_home.html")

def account_add(request):
    return render(request,"account_add.html")

def save_account(request):
    if request.method == "POST":
        data = account()
        data.account_id = "na"
       
        data.name = request.POST.get('name')
        data.dob = request.POST.get('dob')
        data.role = request.POST.get('role')
        data.status = "Active"
        data.save()
        data.account_id = "account_00" + str(data.id)
        data.save()
        lg = login()
        lg.username = data.account_id
        lg.password = request.POST.get('password')
        lg.category = data.role
        lg.save()
        return render(request,"admin_home.html")
    else:
        return HttpResponse("Invalid data type.")

def remove_account_view(request):
    dt = account.objects.all()
    return render(request,"account_remove.html",{'data':dt})

def remove(request,id):
    dt = account.objects.get(id=id)
    dt.delete()
    return render(request,"admin_home.html")

def suspend_account(request):
    data = account.objects.filter(status="Active")
    return render(request,"account_suspend.html",{'acc':data})

def suspend(request,id):
    data = account.objects.get(id=id)
    data.status = "Suspended"
    data.save()
    return render(request,"admin_home.html")

def add_menu(request):
    return render(request,"menu_add.html")

def save_menu(request):
    if request.method == "POST":
        photo = request.FILES['photo']
        fs = FileSystemStorage()
        filename = fs.save(photo.name, photo)
        uploaded_file_url = fs.url(filename)
        data = menu()
        data.menu_id = "na"
        data.item_name = request.POST.get('item_name')
        data.unit = request.POST.get('unit')
        data.price = request.POST.get('price')
        data.description = request.POST.get('description')
        data.photo = uploaded_file_url
        data.preparation_time = request.POST.get('time')
        data.status ="active"
        data.save()
        data.menu_id = "menu_00" + str(data.id)
        data.save()
        return render(request,"admin_home.html")
    else:
        return HttpResponse("Invalid data type.")

def remove_menu_view(request):
    dt = menu.objects.all()
    return render(request,"remove_menu.html",{'m':dt})

def remove_menu(request,id):
    data = menu.objects.get(id=id)
    data.delete()
    return render(request,"admin_home.html")

def update_price_view(request):
    data = menu.objects.all()
    return render(request,"update_price_view.html",{'m':data})

def update_price(request,id):
    data = menu.objects.get(id=id)
    return render(request,"update_price.html",{'i':data})

def update(request,id):
    dt = menu.objects.get(id=id)
    if request.method == "POST":
        dt.price = request.POST.get('price')
        dt.save()
        return render(request,"admin_home.html")
    else:
        return HttpResponse("Invalid data type.")

def table_add(request):
    return render(request,"table_add.html")

def save_table(request):
    data = table()
    data.table_id = "na"
    data.chairs = request.POST.get('no_of_chairs')
    data.password=request.POST.get('password')
    data.status="active"
    data.save()
    data.table_id = "table_00" + str(data.id)
    data.save()
    lg = login()
    lg.username = data.table_id
    lg.password = request.POST.get('password')
    lg.category = "Table"
    lg.save()
    return render(request,"admin_home.html")

def remove_table_view(request):
    data = table.objects.all()
    return render(request,"table_remove.html",{'t':data})

def remove_table(request,id):
    data = table.objects.get(id=id)
    data.delete()
    return render(request,"admin_home.html")

def login_page(request):
    return render(request,"login_page.html")

def save_login(request):
    if request.method == 'POST':
        data = login.objects.all()
        uname = request.POST.get('uname')
        pwd = request.POST.get('pwd')
        flag = 0
        for d in data:
            if uname == d.username and pwd == d.password:
                type = d.category
                request.session['uid'] = uname
                flag = 1
                if type == "Admin":
                    return redirect('/adminhome/')
                elif type == "Kitchen":
                    return redirect('/kitchenhome/')
                elif type == "Counter":
                    return redirect('/counterhome/')
                elif type == "Table":
                    return redirect('/tablehome/')
                else:
                    return HttpResponse("Invalid acc type.")
        if flag == 0:
            return HttpResponse("Invalid user.")
                
def kitchen_home(request):
    return render(request,"kitchen_home.html")
def counter_home(request):
    return render(request,"counter_home.html")
def table_home(request):
    return render(request,"table_home.html")

def view_menu(request):
    td=request.session['uid']
    data1=table.objects.get(table_id=td)
    st=data1.status
    if st=="active":
        data = menu.objects.all()
        return render(request,"view_menu.html",{'m':data})
    else:   
        return HttpResponse("table not availble...........") 

def order_menu(request,id):
    data = menu.objects.get(id=id)
    return render(request,"order_menu.html",{'i':data})

def save_order(request,id):
    data = menu.objects.get(id=id)
    dt = order_details()
    if 'oid' not in request.session:
        dt.detail_id = "na"
        dt.order_id = "na"
        dt.item_id = data.menu_id
        dt.name = data.item_name
        dt.price = data.price
        dt.qty = request.POST.get('qty')
        dt.status = "pending"
        dt.total_amount = request.POST.get('total_amount')
        dt.save()
        dt.detail_id = "detail_00" + str(dt.id)
        dt.order_id = "order_00" + str(dt.id)
        or1="order_00" + str(dt.id)
        request.session['oid']=or1
        dt.save()
        return redirect('/view_menu/')
    else:    
        dt.detail_id = "na"
        dt.order_id = "na"
        dt.item_id = data.menu_id
        dt.name = data.item_name
        dt.price = data.price
        dt.qty = request.POST.get('qty')
        dt.status = "pending"
        dt.total_amount = request.POST.get('total_amount')
        dt.save()
        dt.detail_id = "detail_00" + str(dt.id)
        dt.order_id = request.session['oid']
        dt.save()
        return redirect('/view_menu/')
def finish(request):
    if 'uid' not in request.session:
        return render(request,'login.html')
    else:
        td=request.session['uid']
        oo=request.session['oid']
        amount =order_details.objects.filter(order_id=oo).aggregate(sum=Sum('total_amount'))['sum']
        dt = order()
        dt.order_id = oo
        # dt.order_id = "order_00" + str(dt.id)
        dt.table_id = request.session['uid']
        dt.order_time = datetime.datetime.now().time() 
        dt.order_date = datetime.datetime.now().date()
        dt.status = "pending"
        dt.bill_amount = amount
        dt.save()
        data=table.objects.get(table_id=td)
        data.status="pending"
        data.save()
        del request.session['oid']
        return render(request,'table_home.html')
        
def give_complaint(request):
    return render(request,"give_complaint.html")

def give_review(request):
    m = menu.objects.all()
    return render(request,"give_review.html",{'data':m})

def save_complaint(request):
    if request.method == "POST":
        comp = complaint()
        un = request.session['uid']
        user = account.objects.get(account_id=un)
        comp.complaint_id = "na"
        comp.username = un
        comp.name = user.name
        comp.complaint = request.POST.get('complaint')
        now = datetime.datetime.now()
        time1 = now.strftime("%Y-%m-%d")
        comp.complaint_date =time1
        comp.save()
        comp.complaint_id = "complaint_00" + str(comp.id)
        comp.save()
        return redirect('/tablehome/')
    else:
        return HttpResponse("Invalid data type.")

def save_review(request):
    if request.method == "POST":
        rw = review()
        rw.review_id = "na"
        rw.table_no = request.session['uid']
        rw.customer_name = request.POST.get('name')
        rw.phone = request.POST.get('phone')
        rw.menu_id = request.POST.get('menu_id')
        rw.review = request.POST.get('review')
        rw.save()
        rw.review_id = "review_00" + str(rw.id)
        rw.save()
        return redirect('/tablehome/')
    else:
        return HttpResponse("Invalid data type.")

def public_view_menu(request):
    data = menu.objects.all()
    return render(request,"public_view_menu.html",{'m':data})

def view_review(request,id):
    rw = review.objects.filter(menu_id=id)
    return render(request,"view_review.html",{'r':rw})

def order_view(request):
    data = order.objects.filter(status='pending')
    return render(request,"kitchen_view_order.html",{'odr':data})

def view_more(request,id):
    data = order_details.objects.filter(order_id=id)
    return render(request,"kitchen_view_orderdetails.html",{'det':data,'j':id})

def accept_order(request,id,oid):
    data = order_details.objects.get(id=id)
    data.status = "Accepted"
    data.save()
    d = order.objects.get(order_id=oid)
    d.bill_amount = order_details.objects.filter(order_id=oid, status='Accepted').aggregate(sum=Sum('total_amount'))['sum']
    d.save()
    dt = order_details.objects.filter(order_id=oid)
    return render(request,"kitchen_view_orderdetails.html",{'det':dt,'j':oid})

def reject_order(request,id,oid):
    data = order_details.objects.get(id=id)
    data.status = "Rejected"
    data.save()
    dt = order_details.objects.filter(order_id=oid)
    return render(request,"kitchen_view_orderdetails.html",{'det':dt,'j':oid})

def finish_order(request,id):
    data = order.objects.get(order_id=id)
    data.status = "Processed"
    data.save()
    data1=table.objects.get(table_id=data.table_id)
    data1.status="active"
    data1.save()
    return redirect('/kitchenhome/')

def counter_view_order(request):
    data = order.objects.filter(status='Processed')
    return render(request,"counter_view_order.html",{'d':data})

def bill_gen(request,id):
    data = order_details.objects.filter(order_id=id, status='Accepted')
    # amt = order_details.objects.filter(order_id=id,status='Accepted').aggregate(sum=Sum('total_amount'))['sum']
    return render(request,"counter_generate_bill.html",{'bill':data,'oid':id})

def bill_generate(request,id,ordrid):
    dtt = order_details.objects.filter(order_id=ordrid, status='Accepted')
    data = order_details.objects.get(id=id)
    dt = bill_details()
    if 'bid' not in request.session:
        dt.bill_detail_id = "na"
        dt.bill_no = "na"
        dt.item_id = data.item_id
        dt.name = data.name
        dt.qty = data.qty
        dt.price = data.price
        dt.amount = data.total_amount
        dt.save()
        dt.bill_detail_id = "bill_detail_00" + str(dt.id)
        dt.bill_no = "bill_00" + str(dt.id)
        bill1="bill_00" + str(dt.id)
        request.session['bid']=bill1
        dt.save()
        return render(request,"counter_generate_bill.html",{'bill':dtt,'oid':ordrid})
    else:    
        dt.bill_detail_id = "na"
        dt.bill_no = "na"
        dt.item_id = data.item_id
        dt.name = data.name
        dt.qty = data.qty
        dt.price = data.price
        dt.amount = data.total_amount
        dt.save()
        dt.bill_detail_id = "bill_detail_00" + str(dt.id)
        dt.bill_no = request.session['bid']
        dt.save()
        return render(request,"counter_generate_bill.html",{'bill':dtt,'oid':ordrid})

def finish_bill(request,id):
    dtt = order_details.objects.filter(order_id=id, status='Accepted')
    data = order.objects.get(order_id=id)
    dt = bill()
    if 'bid' not in request.session:
        dt.bill_no = "na"
        dt.order_id = id 
        dt.table_id = data.table_id 
        dt.bill_date = datetime.datetime.now().date()
        dt.bill_time = datetime.datetime.now().time()
        dt.bill_amount = "0"
        dt.status = "pending"        
        dt.save()
        dt.bill_no = "bill_00" + str(dt.id)
        dt.bill_amount = order_details.objects.filter(order_id=id, status='Accepted').aggregate(sum=Sum('total_amount'))['sum']
        dt.save()
        data.status = "Completed"
        data.save()
        return redirect('/counterhome/')
    else:    
        dt.bill_no = request.session['bid']
        dt.order_id = id 
        dt.table_id = data.table_id
        dt.bill_date = datetime.datetime.now().date()
        dt.bill_time = datetime.datetime.now().time() 
        dt.status = "pending"
        dt.bill_amount = "0"
        dt.save()
        dt.bill_amount = order_details.objects.filter(order_id=id, status='Accepted').aggregate(sum=Sum('total_amount'))['sum']
        dt.save()
        data.status = "Completed"
        data.save()
        del request.session['bid']
        return redirect('/counterhome/')

def view_bill(request):
    u = request.session['uid']
    data = bill.objects.get(table_id=u, status='pending')
    return render(request,"table_view_bill.html",{'i':data})

def view_bill_details(request,bid):
    data = bill_details.objects.filter(bill_no=bid)
    dt = bill.objects.get(bill_no=bid)
    return render(request,"table_view_billdetails.html",{'d':data,'b':dt})

def bill_payment(request,b_no,amt):
    return render(request,"bill_payment.html",{'b':b_no,'a':amt})

def save_payment(request):
    if request.method == "POST":
        data = payment()
        data.payment_id = "na"
        data.bill_no = request.POST.get('bill_no')
        data.amount = request.POST.get('amount') 
        data.bank = request.POST.get('bank')
        data.ifsc_code = request.POST.get('ifsc')
        data.acc_no = request.POST.get('acc_no')
        data.save()
        data.payment_id = "payment_00" + str(data.id)
        data.save()
        b = data.bill_no
        dt = bill.objects.get(bill_no=b)
        dt.status = "Paid"
        dt.save()
        return redirect('/tablehome/')
    else:
        return HttpResponse('Invalid data type.')

def counter_view_bill(request):
    data = bill.objects.filter(status='Paid')
    return render(request,"counter_view_bill.html",{'d':data})

def counter_view_payment(request,bid):
    data = payment.objects.filter(bill_no=bid)
    return render(request,"counter_view_payment.html",{'d':data})

def view_complaints(request):
    data = complaint.objects.all()
    return render(request,"view_complaints.html",{'d':data})