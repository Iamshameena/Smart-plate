from django.db import models

# Create your models here.
class account(models.Model):
    account_id = models.CharField(max_length=30)
    account_number = models.CharField(max_length=40)
    name = models.CharField(max_length=40)
    dob = models.DateField()
    role = models.CharField(max_length=50)
    status = models.CharField(max_length=30)
    class Meta:
        db_table = "account"

class login(models.Model):
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    category = models.CharField(max_length=50)
    class Meta:
        db_table = "login"

class menu(models.Model):
    menu_id = models.CharField(max_length=30)
    item_name = models.CharField(max_length=50)
    unit = models.CharField(max_length=40)
    price = models.CharField(max_length=50)
    description = models.CharField(max_length=220)
    photo = models.CharField(max_length=225)
    preparation_time = models.CharField(max_length=30)
    status = models.CharField(max_length=50)
    class Meta:
        db_table = "menu"

class table(models.Model):
    table_id = models.CharField(max_length=30)
    chairs = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    status = models.CharField(max_length=50)
    class Meta:
        db_table = "table"

class order(models.Model):
    order_id = models.CharField(max_length=30)
    table_id = models.CharField(max_length=30)
    order_date = models.DateField()
    order_time = models.TimeField()
    status = models.CharField(max_length=50)
    bill_amount = models.IntegerField()
    class Meta:
        db_table = "order"

class order_details(models.Model):
    detail_id = models.CharField(max_length=30)
    order_id = models.CharField(max_length=30)
    item_id = models.CharField(max_length=30)
    name = models.CharField(max_length=50)
    price = models.CharField(max_length=50)
    qty = models.CharField(max_length=50)
    status = models.CharField(max_length=50)
    total_amount = models.IntegerField()
    class Meta:
        db_table = "order_details"

class complaint(models.Model):
    complaint_id = models.CharField(max_length=40)
    username = models.CharField(max_length=30)
    name = models.CharField(max_length=50)
    complaint = models.CharField(max_length=220)
    complaint_date = models.DateField()
    class Meta:
        db_table = "complaint"

class review(models.Model):
    review_id = models.CharField(max_length=30)
    table_no = models.CharField(max_length=30)
    customer_name = models.CharField(max_length=50)
    phone = models.CharField(max_length=10)
    menu_id = models.CharField(max_length=30)
    review = models.CharField(max_length=220)
    class Meta:
        db_table = "review"

class bill(models.Model):
    bill_no = models.CharField(max_length=40)
    order_id = models.CharField(max_length=30)
    table_id = models.CharField(max_length=30)
    bill_date = models.DateField()
    bill_time = models.TimeField()
    bill_amount = models.CharField(max_length=50)
    status = models.CharField(max_length=50)
    class Meta:
        db_table = "bill"

class bill_details(models.Model):
    bill_detail_id = models.CharField(max_length=40)
    bill_no = models.CharField(max_length=40)
    item_id = models.CharField(max_length=40)
    name = models.CharField(max_length=50)
    qty = models.CharField(max_length=20)
    price = models.CharField(max_length=50)
    amount = models.CharField(max_length=50)
    class Meta:
        db_table = "bill_details"

class payment(models.Model):
    payment_id = models.CharField(max_length=50)
    bill_no = models.CharField(max_length=40)
    amount = models.CharField(max_length=40)
    bank = models.CharField(max_length=50)
    ifsc_code = models.CharField(max_length=50)
    acc_no = models.CharField(max_length=50)
    class Meta:
        db_table = "payment"